
import React, { useEffect, useState } from 'react';

const Dashboard = () => {
  const [appointments, setAppointments] = useState([]);

  useEffect(() => {
    const fetchAppointments = async () => {
      const response = await fetch('http://localhost:4000/appointments');
      const data = await response.json();
      setAppointments(data);
    };
    fetchAppointments();
  }, []);

  return (
    <div>
      <h2>Agendamentos</h2>
      <ul>
        {appointments.map((appt, idx) => (
          <li key={idx}>
            {appt.date} com link: {appt.link}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Dashboard;
